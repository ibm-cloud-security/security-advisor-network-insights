# Intro
You can use the following steps to install an agent to collect network flow logs from your Kubernetes cluster. These network flow logs are stored in your Cloud Object Storage (COS) instance. Then, you can enable Security Advisor Network Insights to analyze your network flow logs to detect and alert you to suspicious network activity. Repeat the installation in each Kubernetes cluster that you want to monitor.

# Prerequisites
- For Windows 10, before starting with steps mentioned above, activate WSL (Windows Subsystem for Linux) and install [Ubuntu shell](https://win10faq.com/install-run-ubuntu-bash-windows-10/)
- yq CLI
  - For MacOS, Windows 10: Install [yq CLI](http://mikefarah.github.io/yq/)
  - For CentOS, Red Hat and Ubuntu : Install yq CLI version 1.15 by running the following commands:      
  `wget https://github.com/mikefarah/yq/releases/download/1.15.0/yq_linux_amd64`       
  `mv yq_linux_amd64 yq`     
  `chmod +x yq`     
  `mv yq /usr/local/bin/`       
  `yq -V`       
- cURL binary
  - For CentOS and Red Hat, update cURL binary by using `yum update -y nss curl libcurl`
- Install [Kubernetes CLI (kubectl)](https://kubernetes.io/docs/tasks/tools/install-kubectl/) v1.10.11 or higher
- Install [Kubernetes Helm (package manager)](https://docs.helm.sh/using_helm/#from-script) v2.9.0 or higher
- Before you install the agent, verify that Helm TLS is enabled. It is recommended that you [enable TLS](https://github.com/helm/helm/blob/master/docs/tiller_ssl.md) in your Helm Tiller.                        
  **Note**:    
    - If you are using workstation to handle installation of analytics components in multiple clusters and Helm TLS is enabled, be sure that the TLS configuration in your workstation is current and corresponds to the cluster where you are planing to install these components.

# Steps to run
1) Download the tar file.
2) Unzip the file by running `tar -xvf security-advisor-network-insights.tar` in your terminal.
3) Change into the file directory. `cd security-advisor-network-insights`
4) Run the install command.
  ```
  ./network-insight-install.sh <cos_region> <cos_api_key>
  ```
    - The `<cos_region>` value is the region in which your COS is deployed. Options include `us-south` or `eu-gb`.
    - The <cos_api_key> value is the [api key](https://cloud.ibm.com/docs/services/cloud-object-storage/iam?topic=cloud-object-storage-service-credentials#service-credentials) that you created to access your COS instance and bucket. The key should have the Writer IAM service role.
    
   **Note**: When you run the install command the following actions are completed:
   
   - The script checks to see if a bucket that follows the correct naming convention (`sa.<account_id>.telemetric.<cos_region>`) already exists. 
   - It creates Kubernetes secrets with the following details: `cos_region`, `cos_api_key`, `cos_endpoint`, `iam_endpoint`, and `cos_bucket_name`.
   - Then, updates the network-insights-values.yaml file with your cluster GUID and netmask information.
   - Finally, the script deploys the Network Insights Helm chart into your cluster.
   
5) Verify the installation :
     - `helm ls | grep  network-insights` should return a helm release named `network-insights` in DEPLOYED state, use `--tls` flag if Helm is TLS enabled.
     - `kubectl get pods -n security-advisor-insights | grep network-insights` should return two pods related to `network-insights` in the state "RUNNING".

**Note**: If you create your COS instance and bucket outside of the Security Advisor UI, be sure to use the following naming convention for the bucket: `sa.<account_id>.telemetric.<cos_region>`. Also be sure to set up service-to-service [authorization](https://cloud.ibm.com/docs/iam?topic=iam-serviceauth#serviceauth) in IBM Cloud IAM to give Security Advisor permission to read data from your COS instance. Set the `source` service to Security Advisor and the `target` service to your  Cloud Object Storage instance with a `Reader` IAM role.

# Deleting the setup
1) `helm del --purge network-insights` , use `--tls` flag if helm is TLS enabled.
2) `kubectl delete ns security-advisor-insights`

**Note**: Repeat for each cluster where you want to remove the agents that collect network flow logs.

# Troubleshooting
1) If you get an error similar to `Error: incompatible versions client and server`, run `helm init --upgrade`.
2) If you get an error similar to `namespaces security-advisor-insights is forbidden: User system:serviceaccount:kube-system:default cannot get resource namespaces in API group in thenamespace security-advisor-insights`, fix the [helm setup](https://cloud.ibm.com/docs/containers?topic=containers-integrations#helm), as the kube-system default service account does not have the cluster-admin access in your cluster.

