#!/bin/bash

cos_region=$1

if [ "$#" -ne 2 ]; then
    echo "Required arguments missing!"
    echo "Usage : ./network-insight-install.sh <cos_region> <cos_api_key>"
    echo "<cos_region> value is either us-south or eu-gb"
    echo "<cos_api_key> is the api key present in COS service credentials"
    exit 1
fi

cos_api_key=$2

cosEndpoint="https://s3.$cos_region.cloud-object-storage.appdomain.cloud"
iamEndpoint="https://iam.cloud.ibm.com/identity/token"

# Don't run if any of the prerequisites are not installed.
prerequisites=("yq" "kubectl" "helm" "curl")
for i in "${prerequisites[@]}"; do
    isExist=$(command -v $i)
    if [ -z "$isExist" ]; then
        echo "$i not installed. Please install the required pre-requisites first (yq, kubectl, helm, curl)"
        exit 1
    fi
done

# Get cluster info
kubectl get cm cluster-info -n kube-system -o yaml | yq r - data[cluster-config.json] > cluster-config.yaml
cluster_id=$(yq r cluster-config.yaml | yq r - cluster_id)
cluster_pay_tier=$(yq r cluster-config.yaml | yq r - cluster_pay_tier)
account_id=$(yq r cluster-config.yaml | yq r - account_id)
bucketName="sa.$account_id.telemetric.$cos_region"
subnet=""
worker_ips=""

# Check for the OS type and set executable accordingly.
osType=$(uname)
if [ "$osType" = "Linux" ]; then
    # Running on a Linux variant.
    encode="base64 -w 0"
else
    # Running on macOS.
    encode="base64"
fi

ACCESS_TOKEN=$(curl -s -X POST \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -H "Accept: application/json" \
    -d "grant_type=urn%3Aibm%3Aparams%3Aoauth%3Agrant-type%3Aapikey&apikey=$cos_api_key" \
    "$iamEndpoint" | yq r - access_token)

bucketStatus=$(curl -s -X GET -H "Authorization: Bearer $ACCESS_TOKEN" $cosEndpoint/$bucketName)
if [[ "$bucketStatus" =~ "The specified bucket does not exist" ]]; then
    echo "Bucket $bucketName does not exists. Please create one using the Security Advisor UI"
    exit 1
fi

cos_region_encoded=$(echo -n $cos_region | $encode)
cos_api_key_encoded=$(echo -n $cos_api_key | $encode)
bucketName_encoded=$(echo -n $bucketName | $encode)
cosEndpoint_encoded=$(echo -n $cosEndpoint | $encode)
iamEndpoint_encoded=$(echo -n $iamEndpoint | $encode)

yq w -i secret-template.yaml data.cosEndpoint $cosEndpoint_encoded
yq w -i secret-template.yaml data.cosApiKey $cos_api_key_encoded
yq w -i secret-template.yaml data.bucketName $bucketName_encoded
yq w -i secret-template.yaml data.iamEndpoint $iamEndpoint_encoded
yq w -i secret-template.yaml data.cosRegion $cos_region_encoded

# Check if the cluster is Lite or Paid.
if [ "$cluster_pay_tier" != "free" ]; then
    kubectl get cm -n kube-system -o yaml ibm-cloud-provider-vlan-ip-config > vlan-ip-config.yaml

    # Obtain cluster public subnet.
    isTrue=$(yq r vlan-ip-config.yaml data[vlanipmap.json] | yq r - vlans[0].subnets[0].is_public)

    if [ $isTrue = "true" ]; then
        subnet=$(yq r vlan-ip-config.yaml data[vlanipmap.json] | yq r - vlans[0].subnets[0].cidr)
    else
        subnet=$(yq r vlan-ip-config.yaml data[vlanipmap.json] | yq r - vlans[1].subnets[0].cidr)
    fi
fi

column_number=$(kubectl get nodes -o wide | awk 'NR == 1 { if ($7 == "EXTERNAL-IP") print 7 ; else  print 6 }')

if [ "$column_number" == 7 ]; then
    worker_ips=$(kubectl get nodes -o wide | awk 'NR > 1  {print $7 "/32"}' | tr '\n' ' ')
else
    worker_ips=$(kubectl get nodes -o wide | awk 'NR > 1  {print $6 "/32"}' | tr '\n' ' ')
fi

bfp_values=($(echo $worker_ips | sed 's/\/32//g'))
bpf_src="not (tcp dst port 8082) and not (( src net 10.0.0.0 mask 255.0.0.0 or src net 172.16.0.0 mask 255.240.0.0 or src net 192.168.0.0 mask 255.255.0.0"
bpf_dest="and ( dst net 10.0.0.0 mask 255.0.0.0 or dst net 172.16.0.0 mask 255.240.0.0 or dst net 192.168.0.0 mask 255.255.0.0"

for element in "${bfp_values[@]}"; do
    bpf_src="$bpf_src or src net $element mask 255.255.255.255"
    bpf_dest="$bpf_dest or dst net $element mask 255.255.255.255"
done

if [ "$subnet" != "" ]; then
    new_subnet=$(echo $subnet | sed 's/\/29//g')
    bpf_src="$bpf_src or src net $new_subnet mask 255.255.255.248"
    bpf_dest="$bpf_dest or dst net $new_subnet mask 255.255.255.248"
fi

cluster_vms_skydive="10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 $worker_ips$subnet"

yq w -i network-insights-values.yaml env[12].value "$cluster_vms_skydive"
yq w -i network-insights-values.yaml env[10].value "$cluster_id"
yq w -i network-insights-values.yaml env[14].value "$bpf_src ) $bpf_dest ))"

tls='--tls'
enabled='N'
tlsStatus=$(helm ls 2>&1)
if [[ "$tlsStatus" != "Error: transport is closing" ]]; then
    read -p 'Warning: Helm TLS is not enabled. Do you want to continue? [y/N] ' enabled
    if [ "$enabled" == "y" ]; then
        helm init
        echo "Sleeping for 10 seconds so that tiller pod is ready"
        sleep 10
        tls=''
    else
        echo "Setup helm TLS. Follow https://github.com/helm/helm/blob/master/docs/tiller_ssl.md"
        exit 1
    fi
fi

nsCreateCmd=$(kubectl create namespace security-advisor-insights 2>&1)
if [[ "$nsCreateCmd" =~ "already exists" ]]; then
    echo "Warning: Namespace 'security-advisor-insights' already exist. Proceeding with the same."
else
    echo "Namespace 'security-advisor-insights' created successfully"
fi

icrSecretCreateCmd=$(kubectl get secret default-icr-io -o yaml | sed "s/default/security-advisor-insights/g" | kubectl -n security-advisor-insights create -f - 2>&1)

if [[ "$icrSecretCreateCmd" =~ "created" ]]; then
    echo "Secret 'security-advisor-insights-icr-io' created successfully"
elif [[ "$icrSecretCreateCmd" =~ "already exists" ]]; then
    echo "Secret 'security-advisor-insights-icr-io' exists"
else
    echo "Error creating secret 'security-advisor-insights-icr-io'"
    exit 1
fi

kubectl apply -f secret-template.yaml

helmInstallCmd=$(helm install $tls -n network-insights network-insights-chart --namespace security-advisor-insights -f network-insights-values.yaml --wait --timeout 400 2>&1)
helmStatus=$(helm status network-insights -o json $tls | yq r - info.status.code)
if [[ "$helmStatus" == "1" && "$helmInstallCmd" != *"Error"* ]]; then
    echo "Network insights helm chart installation successful!"
else
    echo "$helmInstallCmd"
    echo "Network insights helm chart installation Failed!"
fi
